plugins {
    id("com.android.application"); id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose"); id("com.google.devtools.ksp")
}
android {
    namespace = "com.spareparts.manager"; compileSdk = 34
    defaultConfig { applicationId = "com.spareparts.manager"; minSdk = 24; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    buildFeatures { compose = true }
}
dependencies {
    val room = "2.6.1"
    implementation("androidx.room:room-runtime:$room"); implementation("androidx.room:room-ktx:$room")
    ksp("androidx.room:room-compiler:$room")
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3"); implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui-tooling-preview"); implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.navigation:navigation-compose:2.8.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6"); implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    // Next: CameraX + ML Kit barcode scanning, ZXing (Code128/EAN generation)
}
