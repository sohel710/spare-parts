package com.spareparts.manager.data
import android.content.Context
import androidx.room.*

@Database(entities = [Category::class, Brand::class, Supplier::class, Customer::class, Product::class, Sale::class, SaleItem::class,
    Purchase::class, PurchaseItem::class, Payment::class, StockTransaction::class, Warranty::class, Setting::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): Dao
    companion object {
        @Volatile private var i: AppDatabase? = null
        fun get(c: Context) = i ?: synchronized(this) {
            i ?: Room.databaseBuilder(c.applicationContext, AppDatabase::class.java, "spareparts.db").build().also { i = it }
        }
    }
}
