package com.spareparts.manager.ui
import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.spareparts.manager.R
import com.spareparts.manager.data.*
import kotlinx.coroutines.flow.*

data class Stats(val sales: Double, val purchases: Double, val profit: Double, val stockValue: Double, val products: Int,
                 val low: Int, val customers: Int, val suppliers: Int, val dues: Double, val warranties: Int)

class DashboardVM(app: Application) : AndroidViewModel(app) {
    private val d = AppDatabase.get(app).dao()
    private val from = Repository(AppDatabase.get(app)).startOfToday()
    val stats: StateFlow<Stats?> = combine(listOf(d.salesSince(from), d.purchasesSince(from), d.profitSince(from), d.stockValue(), d.productCount(),
        d.lowStockCount(), d.customerCount(), d.supplierCount(), d.customerDues(), d.activeWarranties(System.currentTimeMillis()))) { v ->
        Stats(v[0] as Double, v[1] as Double, v[2] as Double, v[3] as Double, v[4] as Int, v[5] as Int, v[6] as Int, v[7] as Int, v[8] as Double, v[9] as Int)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
}

private data class Tab(val route: String, val label: Int, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable fun AppRoot() {
    val tabs = listOf(Tab("dashboard", R.string.dashboard, Icons.Default.Dashboard), Tab("sales", R.string.sales, Icons.Default.PointOfSale),
        Tab("stock", R.string.stock, Icons.Default.Inventory2), Tab("customers", R.string.customers, Icons.Default.People), Tab("more", R.string.more, Icons.Default.MoreHoriz))
    val nav = rememberNavController()
    val current = nav.currentBackStackEntryAsState().value?.destination?.route
    Scaffold(bottomBar = {
        NavigationBar { tabs.forEach { t ->
            NavigationBarItem(selected = current == t.route, onClick = { nav.navigate(t.route) { popUpTo("dashboard"); launchSingleTop = true } },
                icon = { Icon(t.icon, null) }, label = { Text(stringResource(t.label)) }) } }
    }) { pad ->
        NavHost(nav, "dashboard", Modifier.padding(pad)) {
            composable("dashboard") { DashboardScreen() }
            tabs.drop(1).forEach { t -> composable(t.route) { Box(Modifier.fillMaxSize().padding(16.dp)) { Text(stringResource(t.label), style = MaterialTheme.typography.headlineSmall) } } }
        }
    }
}

@Composable fun DashboardScreen(vm: DashboardVM = viewModel()) {
    val s by vm.stats.collectAsStateWithLifecycle()
    val st = s ?: return Box(Modifier.fillMaxSize()) { CircularProgressIndicator(Modifier.padding(32.dp)) }
    val cards = listOf(R.string.today_sales to "%.0f".format(st.sales), R.string.today_purchases to "%.0f".format(st.purchases),
        R.string.today_profit to "%.0f".format(st.profit), R.string.stock_value to "%.0f".format(st.stockValue),
        R.string.products to "${st.products}", R.string.low_stock to "${st.low}", R.string.total_customers to "${st.customers}",
        R.string.total_suppliers to "${st.suppliers}", R.string.dues to "%.0f".format(st.dues), R.string.warranty to "${st.warranties}")
    LazyVerticalGrid(GridCells.Fixed(2), Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(cards.size) { i -> ElevatedCard { Column(Modifier.padding(16.dp)) {
            Text(stringResource(cards[i].first), style = MaterialTheme.typography.labelLarge)
            Text(cards[i].second, style = MaterialTheme.typography.headlineMedium) } } }
    }
}
