package com.spareparts.manager.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao interface Dao {
    @Insert suspend fun insert(p: Product): Long
    @Update suspend fun update(p: Product)
    @Insert suspend fun insert(c: Customer): Long
    @Insert suspend fun insert(s: Supplier): Long
    @Insert suspend fun insert(s: Sale): Long
    @Insert suspend fun insertSaleItems(i: List<SaleItem>)
    @Insert suspend fun insert(p: Purchase): Long
    @Insert suspend fun insertPurchaseItems(i: List<PurchaseItem>)
    @Insert suspend fun insert(t: StockTransaction)
    @Insert suspend fun insert(w: Warranty)
    @Insert suspend fun insert(p: Payment)
    @Insert suspend fun insert(c: Category): Long
    @Insert suspend fun insert(b: Brand): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(s: Setting)

    @Query("SELECT * FROM products WHERE id=:id") suspend fun product(id: Long): Product?
    @Query("SELECT * FROM products WHERE barcode=:code LIMIT 1") suspend fun byBarcode(code: String): Product?
    @Query("SELECT * FROM products WHERE name LIKE '%'||:q||'%' OR partNumber LIKE '%'||:q||'%' OR sku LIKE '%'||:q||'%' OR barcode=:q ORDER BY name")
    fun search(q: String): Flow<List<Product>>
    @Query("SELECT * FROM products WHERE stock<=minStock ORDER BY stock") fun lowStock(): Flow<List<Product>>
    @Query("UPDATE products SET stock=stock+:delta WHERE id=:id") suspend fun addStock(id: Long, delta: Int)
    @Query("SELECT value FROM settings WHERE key=:k") suspend fun setting(k: String): String?
    @Query("SELECT COUNT(*) FROM sales WHERE invoiceNo LIKE :prefix||'%'") suspend fun salesCount(prefix: String): Int
    @Query("SELECT COUNT(*) FROM purchases WHERE purchaseNo LIKE :prefix||'%'") suspend fun purchaseCount(prefix: String): Int

    // dashboard aggregates
    @Query("SELECT COALESCE(SUM(grandTotal),0) FROM sales WHERE timestamp>=:from") fun salesSince(from: Long): Flow<Double>
    @Query("SELECT COALESCE(SUM(total),0) FROM purchases WHERE timestamp>=:from") fun purchasesSince(from: Long): Flow<Double>
    @Query("SELECT COALESCE(SUM(si.qty*(si.unitPrice-si.unitCost)-si.discount),0) FROM sale_items si JOIN sales s ON s.id=si.saleId WHERE s.timestamp>=:from")
    fun profitSince(from: Long): Flow<Double>
    @Query("SELECT COALESCE(SUM(stock*purchasePrice),0) FROM products") fun stockValue(): Flow<Double>
    @Query("SELECT COUNT(*) FROM products") fun productCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM products WHERE stock<=minStock") fun lowStockCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM customers") fun customerCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM suppliers") fun supplierCount(): Flow<Int>
    @Query("SELECT COALESCE(SUM(grandTotal-paid),0) FROM sales") fun customerDues(): Flow<Double>
    @Query("SELECT COUNT(*) FROM warranties WHERE expiryDate>=:now") fun activeWarranties(now: Long): Flow<Int>
    @Query("SELECT * FROM sales ORDER BY timestamp DESC LIMIT 5") fun recentSales(): Flow<List<Sale>>
    @Query("SELECT * FROM purchases ORDER BY timestamp DESC LIMIT 5") fun recentPurchases(): Flow<List<Purchase>>
}
