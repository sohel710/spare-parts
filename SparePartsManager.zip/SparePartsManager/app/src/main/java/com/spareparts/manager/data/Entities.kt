package com.spareparts.manager.data
import androidx.room.*

@Entity(tableName = "categories", indices = [Index("name", unique = true)])
data class Category(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)
@Entity(tableName = "brands", indices = [Index("name", unique = true)])
data class Brand(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)
@Entity(tableName = "suppliers")
data class Supplier(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val company: String = "", val phone: String = "", val address: String = "", val notes: String = "")
@Entity(tableName = "customers", indices = [Index("phone")])
data class Customer(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val phone: String = "", val address: String = "", val notes: String = "")

@Entity(tableName = "products", indices = [Index("barcode"), Index("sku"), Index("partNumber")],
    foreignKeys = [
        ForeignKey(Category::class, ["id"], ["categoryId"], onDelete = ForeignKey.SET_NULL),
        ForeignKey(Brand::class, ["id"], ["brandId"], onDelete = ForeignKey.SET_NULL),
        ForeignKey(Supplier::class, ["id"], ["supplierId"], onDelete = ForeignKey.SET_NULL)])
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, val partNumber: String = "", val categoryId: Long? = null, val brandId: Long? = null,
    val compatibleModel: String = "", val sku: String = "", val barcode: String = "",
    val purchasePrice: Double, val sellingPrice: Double, val stock: Int = 0, val minStock: Int = 5,
    val supplierId: Long? = null, val warrantyMonths: Int = 0, val imagePath: String? = null, val notes: String = "")
val Product.profitPerUnit get() = sellingPrice - purchasePrice
val Product.profitPercent get() = if (purchasePrice > 0) profitPerUnit / purchasePrice * 100 else 0.0
val Product.stockValue get() = stock * purchasePrice
val Product.isLow get() = stock <= minStock
val Product.suggestedReorder get() = (minStock * 2 - stock).coerceAtLeast(0)

@Entity(tableName = "sales", indices = [Index("invoiceNo", unique = true), Index("timestamp")])
data class Sale(@PrimaryKey(autoGenerate = true) val id: Long = 0, val invoiceNo: String, val customerId: Long?, val timestamp: Long,
    val subtotal: Double, val discount: Double, val grandTotal: Double, val paid: Double, val method: String) { val due get() = grandTotal - paid }
@Entity(tableName = "sale_items", indices = [Index("saleId"), Index("productId")],
    foreignKeys = [ForeignKey(Sale::class, ["id"], ["saleId"], onDelete = ForeignKey.CASCADE)])
data class SaleItem(@PrimaryKey(autoGenerate = true) val id: Long = 0, val saleId: Long, val productId: Long,
    val qty: Int, val unitPrice: Double, val unitCost: Double, val discount: Double = 0.0)

@Entity(tableName = "purchases", indices = [Index("purchaseNo", unique = true)])
data class Purchase(@PrimaryKey(autoGenerate = true) val id: Long = 0, val purchaseNo: String, val supplierInvoice: String = "", val supplierId: Long?,
    val timestamp: Long, val total: Double, val paid: Double, val notes: String = "") { val due get() = total - paid }
@Entity(tableName = "purchase_items", indices = [Index("purchaseId"), Index("productId")],
    foreignKeys = [ForeignKey(Purchase::class, ["id"], ["purchaseId"], onDelete = ForeignKey.CASCADE)])
data class PurchaseItem(@PrimaryKey(autoGenerate = true) val id: Long = 0, val purchaseId: Long, val productId: Long, val qty: Int, val unitCost: Double)

/** partyType = "CUSTOMER" | "SUPPLIER"; a later payment against a due balance. */
@Entity(tableName = "payments") data class Payment(@PrimaryKey(autoGenerate = true) val id: Long = 0,
    val partyType: String, val partyId: Long, val refNo: String = "", val amount: Double, val method: String, val timestamp: Long)
/** type = SALE | PURCHASE | ADJUST | IN | OUT; delta is signed. */
@Entity(tableName = "stock_transactions", indices = [Index("productId")])
data class StockTransaction(@PrimaryKey(autoGenerate = true) val id: Long = 0, val productId: Long, val delta: Int, val type: String,
    val refNo: String = "", val timestamp: Long, val note: String = "")
@Entity(tableName = "warranties", indices = [Index("expiryDate")])
data class Warranty(@PrimaryKey(autoGenerate = true) val id: Long = 0, val productId: Long, val customerId: Long?, val invoiceNo: String,
    val saleDate: Long, val months: Int, val expiryDate: Long)
@Entity(tableName = "settings") data class Setting(@PrimaryKey val key: String, val value: String)
