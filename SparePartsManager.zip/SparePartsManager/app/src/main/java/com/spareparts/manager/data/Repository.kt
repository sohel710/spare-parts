package com.spareparts.manager.data
import androidx.room.withTransaction
import java.time.*
import java.time.format.DateTimeFormatter

data class SaleLine(val productId: Long, val qty: Int, val unitPrice: Double, val discount: Double = 0.0)
data class PurchaseLine(val productId: Long, val qty: Int, val unitCost: Double)
class BusinessError(msg: String) : Exception(msg)

class Repository(private val db: AppDatabase) {
    private val d = db.dao()
    private fun day() = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE)
    private fun now() = System.currentTimeMillis()
    fun startOfToday() = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()

    suspend fun nextInvoiceNo() = "INV-${day()}-%04d".format(d.salesCount("INV-${day()}-") + 1)
    suspend fun nextPurchaseNo() = "PUR-${day()}-%04d".format(d.purchaseCount("PUR-${day()}-") + 1)

    /** Atomic: validates stock (unless negative stock enabled), saves sale, cuts stock, logs history, creates warranties. */
    suspend fun completeSale(customerId: Long?, lines: List<SaleLine>, paid: Double, method: String): Sale = db.withTransaction {
        if (lines.isEmpty()) throw BusinessError("Add at least one item")
        val allowNegative = d.setting("negative_stock") == "true"
        val products = lines.associate { it.productId to (d.product(it.productId) ?: throw BusinessError("Product not found")) }
        lines.forEach { l ->
            require(l.qty > 0) { "Quantity must be positive" }
            val p = products.getValue(l.productId)
            if (!allowNegative && l.qty > p.stock) throw BusinessError("${p.name}: only ${p.stock} in stock")
        }
        val subtotal = lines.sumOf { it.qty * it.unitPrice }
        val discount = lines.sumOf { it.discount }
        val total = subtotal - discount
        if (paid < 0 || paid > total) throw BusinessError("Paid amount must be between 0 and $total")
        val no = nextInvoiceNo(); val t = now()
        val sale = Sale(invoiceNo = no, customerId = customerId, timestamp = t, subtotal = subtotal, discount = discount, grandTotal = total, paid = paid, method = method)
        val saleId = d.insert(sale)
        d.insertSaleItems(lines.map { SaleItem(saleId = saleId, productId = it.productId, qty = it.qty, unitPrice = it.unitPrice, unitCost = products.getValue(it.productId).purchasePrice, discount = it.discount) })
        lines.forEach { l ->
            d.addStock(l.productId, -l.qty)
            d.insert(StockTransaction(productId = l.productId, delta = -l.qty, type = "SALE", refNo = no, timestamp = t))
            val months = products.getValue(l.productId).warrantyMonths
            if (months > 0) d.insert(Warranty(productId = l.productId, customerId = customerId, invoiceNo = no, saleDate = t, months = months, expiryDate = expiry(t, months)))
        }
        sale.copy(id = saleId)
    }

    /** Atomic: saves purchase and increases stock; also updates the product's latest purchase price. */
    suspend fun recordPurchase(supplierId: Long?, supplierInvoice: String, lines: List<PurchaseLine>, paid: Double, notes: String = ""): Purchase = db.withTransaction {
        if (lines.isEmpty()) throw BusinessError("Add at least one item")
        val total = lines.sumOf { it.qty * it.unitCost }
        if (paid < 0 || paid > total) throw BusinessError("Paid amount must be between 0 and $total")
        val no = nextPurchaseNo(); val t = now()
        val pur = Purchase(purchaseNo = no, supplierInvoice = supplierInvoice, supplierId = supplierId, timestamp = t, total = total, paid = paid, notes = notes)
        val id = d.insert(pur)
        d.insertPurchaseItems(lines.map { PurchaseItem(purchaseId = id, productId = it.productId, qty = it.qty, unitCost = it.unitCost) })
        lines.forEach { l ->
            d.addStock(l.productId, l.qty)
            d.product(l.productId)?.let { d.update(it.copy(purchasePrice = l.unitCost)) }
            d.insert(StockTransaction(productId = l.productId, delta = l.qty, type = "PURCHASE", refNo = no, timestamp = t))
        }
        pur.copy(id = id)
    }

    suspend fun adjustStock(productId: Long, delta: Int, type: String, note: String) = db.withTransaction {
        val p = d.product(productId) ?: throw BusinessError("Product not found")
        if (p.stock + delta < 0 && d.setting("negative_stock") != "true") throw BusinessError("Stock cannot go below zero")
        d.addStock(productId, delta); d.insert(StockTransaction(productId = productId, delta = delta, type = type, timestamp = now(), note = note))
    }

    companion object {
        fun expiry(from: Long, months: Int) = Instant.ofEpochMilli(from).atZone(ZoneId.systemDefault()).plusMonths(months.toLong()).toInstant().toEpochMilli()
        /** ACTIVE / EXPIRING_SOON (<=30 days) / EXPIRED */
        fun warrantyStatus(expiry: Long, now: Long = System.currentTimeMillis()) = when {
            expiry < now -> "EXPIRED"; expiry - now <= 30L * 86_400_000 -> "EXPIRING_SOON"; else -> "ACTIVE" }
    }
}
